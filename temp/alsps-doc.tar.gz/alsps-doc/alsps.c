二个函数对读到寄存器里的值，作一些算法上的处理
static int ltr558_get_als_value(struct ltr558_priv *obj, int als)
static int ltr558_get_ps_value(struct ltr558_priv *obj, int ps)

取校准数据
static int ltr558_read_data_for_cali(struct i2c_client *client,struct PS_CALI_DATA_STRUCT *ps_data_cali)


如何去处理NOISE太大的情况：
        noise=data_total/(COUNT-j);
        if(noise > NOISE_MAX) {
            ps_cali.far_away = 0;
            ps_cali.close = 0;
            ps_cali.valid = 0;

            ps_data_cali->valid = 0;
            ps_data_cali->close = 0;
            ps_data_cali->far_away = 0;
        }
        else
        {
            ps_data_cali->close = noise + NOISE_HIGH;
            ps_data_cali->far_away = noise + NOISE_LOW;
            ps_data_cali->valid = 1;

            ps_cali.close = noise + NOISE_HIGH;
            ps_cali.far_away = noise + NOISE_LOW;
            ps_cali.valid = 1;
        }



int ltr558_als_operate(void* self, uint32_t command, void* buff_in, int size_in,
        void* buff_out, int size_out, int* actualout)
