DECLARE_PER_CPU(struct task_struct *, mtk_next_task);
// define in: kernel/trace/trace_sched_switch.c
extern int  sched_stopped;

