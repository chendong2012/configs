#ifndef __DBG_DUMP_H
#define __DBG_DUMP_H

struct reg_dump_driver_data
{
        u32 mcu_regs;
};

#endif
